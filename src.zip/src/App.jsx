import React from 'react';
import './App.css';
import Header from './components/Header';
import ProductShowcase from './components/ProductShowcase';
import Description from './components/Description';
import ThemeToggle from './components/ThemeToggle';
import Footer from './components/Footer';

function App() {
  const product = {
    name: 'iPhone 14 Pro',
    imageUrl: '/src/components/iphone.jpg',
    description: 'The latest iPhone 14 Pro with an all-new design and advanced features.',
  };

  return (
    <div className="app">
      <Header title="iPhone page" />
      <ThemeToggle />
      <section id="home-section">
        <ProductShowcase imageUrl={product.imageUrl} productName={product.name} />
      </section>
      <section id="service-section">
        <Description text={product.description} />
      </section>
      <section id="contact-section">
        <Footer />
      </section>
    </div>
  );
}

export default App;
