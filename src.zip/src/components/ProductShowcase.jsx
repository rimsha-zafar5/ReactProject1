import React from 'react';

function ProductShowcase({ imageUrl, productName }) {
  return (
    <div className="product-showcase">
      <img src={imageUrl} alt={productName} />
      <h2>{productName}</h2>
    </div>
  );
}

export default ProductShowcase;
