import React from 'react';
function Header({ title }) {
  return (
    <header className="header">
      <h1>{title}</h1>
      <nav className="nav-bar">
        <button className="nav-button" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          Home
        </button>
        <button className="nav-button" onClick={() => document.getElementById('service-section').scrollIntoView({ behavior: 'smooth' })}>
          Service
        </button>
        <button className="nav-button" onClick={() => document.getElementById('contact-section').scrollIntoView({ behavior: 'smooth' })}>
          Contact
        </button>
      </nav>
    </header>
  );
}

export default Header;
